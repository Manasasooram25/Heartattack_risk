A Web Application to predict Heart Attack using Machine Learning Techniques
1.Project Requirements or Dependencies
Anaconda Python (to get ML Libraries)
Pip install flask (For Front-end)

2. Load Dataset
Heart Dataset- Heart.csv

Attribute Information:

age - Age of the patient
sex - Sex of the patient
cp - Chest pain type ~ 0 = Typical Angina, 1 = Atypical Angina, 2 = Non-anginal Pain, 3 = Asymptomatic
trtbps - Resting blood pressure (in mm Hg)
chol - Cholestoral in mg/dl fetched via BMI sensor
fbs - (fasting blood sugar > 120 mg/dl) ~ 1 = True, 0 = False
restecg - Resting electrocardiographic results ~ 0 = Normal, 1 = ST-T wave normality, 2 = Left ventricular hypertrophy
thalachh - Maximum heart rate achieved (Normal heart rate: age-220)
oldpeak - Previous peak (<2- Low, 1.5-4.2- Risk,>2.5-terrible risk)
slp - Slope (0-up, 1-flat, 2-down)
caa - Number of major vessels
thall - Thalium Stress Test result ~ (0,3)
exng - Exercise induced angina ~ 1 = Yes, 0 = No
output - target : 0= less chance of heart attack 1= more chance of heart attack

3.Build and Train the model using Machine Learning Techniques
We start by K-Nearest Neighbor algorithm to build and train a model to predict whether the user is affected by heart attack or not.
We then implement Decision Tree and Support Vector Algorithms to predict the same.

4.Flask Creation
Heart_attack_prediction.ipynb — This contains code for the machine learning model to predict heart attack based on the class.
app.py — This contains Flask APIs that receives user details through GUI or API calls, computes the predicted value based on our model and returns it.
templates & static — This folders contains the HTML template and CSS styling to allow user to enter cells details and displays the predicted output.

5.Backend creation using model.pkl file
Use this pretrained model and connect it with our Flask application. Use this for prediction for model and to show the output.

6. Adding form to flask app

7.Integrating web application with machine learning backend.
